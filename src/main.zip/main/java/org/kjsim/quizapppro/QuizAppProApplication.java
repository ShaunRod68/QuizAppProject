package org.kjsim.quizapppro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QuizAppProApplication {

    public static void main(String[] args) {
        SpringApplication.run(QuizAppProApplication.class, args);
    }

}
